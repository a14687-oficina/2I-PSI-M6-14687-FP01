<?php 
// Inclui a ligação à base de dados e configura o fuso horário para Lisboa
include "config.php"; 
date_default_timezone_set('Europe/Lisbon');

// Obtém o ID do computador a partir do URL (ex: detalhe.php?id=5)
$id = isset($_GET["id"]) ? (int)$_GET["id"] : 0; 

// --- LÓGICA 1: REPORTAR AVARIA ---
// Executado quando o utilizador envia o formulário de avaria
if (isset($_POST['confirmar_avaria'])) {
    $descricao = isset($_POST['descricao_avaria']) ? trim($_POST['descricao_avaria']) : "Sem descrição";
    
    try {
        // Inicia uma transação: ou tudo corre bem, ou nada é gravado (segurança)
        $pdo->beginTransaction();
        $data_atual = date('Y-m-d H:i:s');
        
        // Atualiza o estado do PC para 'Avariado'
        $stmt_update = $pdo->prepare("UPDATE computadores SET estado = 'Avariado' WHERE id_computador = ?");
        $stmt_update->execute([$id]);
        
        // Insere o registo detalhado na tabela de avarias
        $stmt_insert = $pdo->prepare("INSERT INTO avarias (id_computador, descricao, data_registo) VALUES (?, ?, ?)");
        $stmt_insert->execute([$id, $descricao, $data_atual]);
        
        $pdo->commit(); // Confirma as alterações na BD
        header("Location: detalhe.php?id=$id&status=reported");
        exit;
    } catch (Exception $e) {
        $pdo->rollBack(); // Cancela tudo se houver erro
        die("Erro ao registar avaria: " . $e->getMessage());
    }
}

// --- LÓGICA 2: RESOLVER AVARIA ---
// Executado quando o utilizador clica em "Marcar como Reparado"
if (isset($_POST['resolver_avaria'])) {
    try {
        // Repõe o estado do computador para 'Operacional'
        $stmt_resolve = $pdo->prepare("UPDATE computadores SET estado = 'Operacional' WHERE id_computador = ?");
        $stmt_resolve->execute([$id]);
        header("Location: detalhe.php?id=$id&status=resolved");
        exit;
    } catch (Exception $e) {
        die("Erro ao resolver avaria: " . $e->getMessage());
    }
}

// --- LÓGICA 3: REGISTAR MANUTENÇÃO (IDEIA 5) ---
// Executado quando o utilizador regista uma manutenção preventiva
if (isset($_POST['registar_manutencao'])) {
    $tipo = isset($_POST['tipo_manutencao']) ? trim($_POST['tipo_manutencao']) : "Geral";
    $obs = isset($_POST['obs_manutencao']) ? trim($_POST['obs_manutencao']) : "";
    
    try {
        $data_atual = date('Y-m-d H:i:s');
        // Insere o registo na tabela de manutenções
        $stmt_maint = $pdo->prepare("INSERT INTO manutencoes (id_computador, tipo, observacoes, data_manutencao) VALUES (?, ?, ?, ?)");
        $stmt_maint->execute([$id, $tipo, $obs, $data_atual]);
        header("Location: detalhe.php?id=$id&status=maint_ok");
        exit;
    } catch (Exception $e) {
        die("Erro ao registar manutenção: " . $e->getMessage());
    }
}

// --- BUSCA DE DADOS PARA EXIBIÇÃO ---
// 1. Busca os dados técnicos do computador
$stmt = $pdo->prepare("SELECT * FROM computadores WHERE id_computador = ?"); 
$stmt->execute([$id]); 
$pc = $stmt->fetch(); 

if (!$pc) { die("Computador não encontrado."); } 

// 2. Busca o software instalado (usando INNER JOIN entre software e a tabela de ligação)
$stmt2 = $pdo->prepare(" 
    SELECT s.nome_software, s.versao 
    FROM software s 
    INNER JOIN computador_software cs ON s.id_software = cs.id_software 
    WHERE cs.id_computador = ? 
"); 
$stmt2->execute([$id]); 
$softwares = $stmt2->fetchAll(); 

// 3. Busca o histórico de avarias
$stmt3 = $pdo->prepare("SELECT * FROM avarias WHERE id_computador = ? ORDER BY data_registo DESC");
$stmt3->execute([$id]);
$historico_avarias = $stmt3->fetchAll();

// 4. Busca o histórico de manutenções
$stmt4 = $pdo->prepare("SELECT * FROM manutencoes WHERE id_computador = ? ORDER BY data_manutencao DESC");
$stmt4->execute([$id]);
$historico_manutencoes = $stmt4->fetchAll();
?> 
<!DOCTYPE html> 
<html lang="pt"> 
<head> 
    <meta charset="UTF-8"> 
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Detalhe - <?= htmlspecialchars($pc["nome_computador"]) ?></title> 
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.0/font/bootstrap-icons.css">
    <style> 
        /* Configurações de layout: remove margens do body para a navbar encostar nos lados */
        body { font-family: Arial; background-color: #f8f9fa; margin: 0; padding-bottom: 40px; }
        .card { border: none; box-shadow: 0 0.125rem 0.25rem rgba(0, 0, 0, 0.075); border-radius: 10px; }
        .feature-icon { font-size: 1.5rem; color: #0d6efd; margin-right: 15px; width: 30px; text-align: center; }
        
        /* Estilos para as bolinhas de estado (glow effect) */
        .status-dot { height: 12px; width: 12px; border-radius: 50%; display: inline-block; margin-right: 8px; }
        .status-operacional { background-color: #28a745; box-shadow: 0 0 8px #28a745; }
        .status-manutencao { background-color: #ffc107; box-shadow: 0 0 8px #ffc107; }
        .status-avariado { background-color: #dc3545; box-shadow: 0 0 8px #dc3545; }
        .status-text { font-size: 0.9rem; font-weight: bold; text-transform: uppercase; color: #6c757d; }
    </style> 
</head> 
<body> 
    <!-- Barra de Navegação Superior -->
    <nav class="navbar navbar-dark bg-primary mb-4">
        <div class="container-fluid px-4">
            <span class="navbar-brand mb-0 h1"><i class="bi bi-pc-display me-2"></i>Detalhes do Equipamento</span>
        </div>
    </nav>

    <div class="container-fluid px-4"> 
        <!-- Link para voltar e Alertas de Sucesso -->
        <div class="d-flex justify-content-between align-items-center mb-4">
            <a href="index.php" class="btn btn-link text-decoration-none p-0 text-secondary">
                <i class="bi bi-arrow-left"></i> Voltar para a lista
            </a>
            
            <?php if (isset($_GET['status'])): ?>
                <div class="alert alert-info py-1 px-3 mb-0" role="alert">
                    <i class="bi bi-info-circle me-1"></i> 
                    <?php 
                        if($_GET['status'] == 'reported') echo "Avaria registada!";
                        if($_GET['status'] == 'resolved') echo "Equipamento reparado!";
                        if($_GET['status'] == 'maint_ok') echo "Manutenção registada!";
                    ?>
                </div>
            <?php endif; ?>
        </div>

        <div class="row g-4">
            <!-- COLUNA ESQUERDA: Características Técnicas e Botões de Ação -->
            <div class="col-md-6">
                <div class="card mb-4">
                    <div class="card-header bg-white py-3 d-flex justify-content-between align-items-center">
                        <h1 class="h4 mb-0 text-primary"><?= htmlspecialchars($pc["nome_computador"]) ?></h1>
                        <?php
                        $estado = isset($pc["estado"]) ? $pc["estado"] : "Operacional";
                        $classe_status = ($estado == 'Avariado') ? "status-avariado" : (($estado == 'Manutenção') ? "status-manutencao" : "status-operacional");
                        ?>
                        <div class="d-flex align-items-center bg-light px-3 py-1 rounded-pill border">
                            <span class="status-dot <?= $classe_status ?>"></span>
                            <span class="status-text"><?= $estado ?></span>
                        </div>
                    </div>
                    <div class="card-body">
                        <h2 class="h5 mb-4 border-bottom pb-2">Características Técnicas</h2> 
                        <!-- Listagem de especificações com ícones -->
                        <div class="d-flex align-items-center mb-3"><i class="bi bi-cpu feature-icon"></i><div><small class="text-muted d-block">Processador</small><strong><?= htmlspecialchars($pc["processador"]) ?></strong></div></div>
                        <div class="d-flex align-items-center mb-3"><i class="bi bi-memory feature-icon"></i><div><small class="text-muted d-block">Memória RAM</small><strong><?= htmlspecialchars($pc["ram"]) ?></strong></div></div>
                        <div class="d-flex align-items-center mb-3"><i class="bi bi-hdd feature-icon"></i><div><small class="text-muted d-block">Armazenamento</small><strong><?= htmlspecialchars($pc["armazenamento"]) ?></strong></div></div>
                        <div class="d-flex align-items-center mb-4"><i class="bi bi-window feature-icon"></i><div><small class="text-muted d-block">Sistema Operativo</small><strong><?= htmlspecialchars($pc["sistema_operativo"]) ?></strong></div></div>

                        <!-- BOTÕES DE AÇÃO: Reportar Avaria ou Registar Manutenção -->
                        <div class="row g-2 border-top pt-3">
                            <div class="col-6">
                                <button type="button" class="btn btn-outline-danger w-100" data-bs-toggle="modal" data-bs-target="#modalAvaria" <?= ($estado == 'Avariado') ? 'disabled' : '' ?>>
                                    <i class="bi bi-exclamation-triangle me-1"></i> Avaria
                                </button>
                            </div>
                            <div class="col-6">
                                <button type="button" class="btn btn-outline-primary w-100" data-bs-toggle="modal" data-bs-target="#modalManutencao">
                                    <i class="bi bi-tools me-1"></i> Manutenção
                                </button>
                            </div>
                            <!-- Botão para resolver avaria (só aparece se o PC estiver avariado) -->
                            <?php if ($estado == 'Avariado'): ?>
                            <div class="col-12 mt-2">
                                <form method="POST" onsubmit="return confirm('Marcar como reparado?');">
                                    <button type="submit" name="resolver_avaria" class="btn btn-success w-100"><i class="bi bi-check-lg me-1"></i> Resolver Avaria</button>
                                </form>
                            </div>
                            <?php endif; ?>
                        </div>
                    </div>
                </div>
            </div>

            <!-- COLUNA DIREITA: Tabs para Software, Avarias e Manutenção -->
            <div class="col-md-6">
                <div class="card h-100">
                    <div class="card-header bg-white">
                        <ul class="nav nav-tabs card-header-tabs" id="myTab" role="tablist">
                            <li class="nav-item"><button class="nav-link active" id="soft-tab" data-bs-toggle="tab" data-bs-target="#soft" type="button">Software</button></li>
                            <li class="nav-item"><button class="nav-link" id="avaria-tab" data-bs-toggle="tab" data-bs-target="#avaria" type="button">Avarias</button></li>
                            <li class="nav-item"><button class="nav-link" id="maint-tab" data-bs-toggle="tab" data-bs-target="#maint" type="button">Manutenção</button></li>
                        </ul>
                    </div>
                    <div class="card-body p-0 tab-content">
                        <!-- TAB SOFTWARE: Lista o software instalado -->
                        <div class="tab-pane fade show active" id="soft">
                            <?php if (count($softwares) == 0): ?> 
                                <p class="p-4 text-center text-muted">Sem software associado.</p>
                            <?php else: ?> 
                                <ul class="list-group list-group-flush"> 
                                    <?php foreach($softwares as $sw): ?> 
                                        <li class="list-group-item d-flex justify-content-between align-items-center py-3">
                                            <span><?= htmlspecialchars($sw["nome_software"]) ?></span>
                                            <span class="badge bg-secondary rounded-pill"><?= htmlspecialchars($sw["versao"]) ?></span>
                                        </li> 
                                    <?php endforeach; ?> 
                                </ul> 
                            <?php endif; ?> 
                        </div>
                        <!-- TAB AVARIAS: Mostra o histórico de queixas -->
                        <div class="tab-pane fade" id="avaria">
                            <?php if (count($historico_avarias) == 0): ?> 
                                <p class="p-4 text-center text-muted">Sem registos.</p>
                            <?php else: ?> 
                                <div class="list-group list-group-flush">
                                    <?php foreach($historico_avarias as $av): ?>
                                        <div class="list-group-item py-3">
                                            <div class="d-flex justify-content-between small mb-1"><span class="text-danger fw-bold">AVARIA</span><span class="text-muted"><?= date('d/m/Y H:i', strtotime($av['data_registo'])) ?></span></div>
                                            <p class="mb-0 small"><?= htmlspecialchars($av['descricao']) ?></p>
                                        </div>
                                    <?php endforeach; ?>
                                </div>
                            <?php endif; ?>
                        </div>
                        <!-- TAB MANUTENÇÃO: Mostra o histórico de intervenções técnicas -->
                        <div class="tab-pane fade" id="maint">
                            <?php if (count($historico_manutencoes) == 0): ?> 
                                <p class="p-4 text-center text-muted">Sem manutenções.</p>
                            <?php else: ?> 
                                <div class="list-group list-group-flush">
                                    <?php foreach($historico_manutencoes as $m): ?>
                                        <div class="list-group-item py-3">
                                            <div class="d-flex justify-content-between small mb-1"><span class="text-primary fw-bold"><?= htmlspecialchars($m['tipo']) ?></span><span class="text-muted"><?= date('d/m/Y H:i', strtotime($m['data_manutencao'])) ?></span></div>
                                            <p class="mb-0 small"><?= htmlspecialchars($m['observacoes']) ?></p>
                                        </div>
                                    <?php endforeach; ?>
                                </div>
                            <?php endif; ?>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div> 

    <!-- MODAL PARA REPORTAR AVARIA -->
    <div class="modal fade" id="modalAvaria" tabindex="-1"><div class="modal-dialog"><div class="modal-content"><form method="POST"><div class="modal-header bg-danger text-white"><h5 class="modal-title">Reportar Avaria</h5><button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal"></button></div><div class="modal-body"><textarea class="form-control" name="descricao_avaria" rows="3" placeholder="Descrição do problema..." required></textarea></div><div class="modal-footer"><button type="submit" name="confirmar_avaria" class="btn btn-danger">Confirmar</button></div></form></div></div></div>

    <!-- MODAL PARA REGISTAR MANUTENÇÃO -->
    <div class="modal fade" id="modalManutencao" tabindex="-1"><div class="modal-dialog"><div class="modal-content"><form method="POST"><div class="modal-header bg-primary text-white"><h5 class="modal-title">Registar Manutenção</h5><button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal"></button></div><div class="modal-body">
        <div class="mb-3"><label class="form-label fw-bold">Tipo de Intervenção</label><select class="form-select" name="tipo_manutencao"><option>Limpeza</option><option>Upgrade Hardware</option><option>Atualização Software</option><option>Formatação</option><option>Outro</option></select></div>
        <div class="mb-3"><label class="form-label fw-bold">Observações Técnicas</label><textarea class="form-control" name="obs_manutencao" rows="3"></textarea></div>
    </div><div class="modal-footer"><button type="submit" name="registar_manutencao" class="btn btn-primary">Registar</button></div></form></div></div></div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body> 
</html>
