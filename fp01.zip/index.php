<?php 
// Inclui o ficheiro de configuração que contém a ligação à base de dados (PDO)
include "config.php"; 

// Define o fuso horário para Lisboa para que as datas e horas coincidam com Portugal
date_default_timezone_set('Europe/Lisbon');

// 1. BUSCA DE SALAS: Obtém todas as salas da base de dados para preencher o menu de seleção (dropdown)
$salas = $pdo->query("SELECT * FROM salas ORDER BY nome_sala ASC")->fetchAll(); 

// 2. PARÂMETROS DE FILTRO: Captura os valores enviados via URL (GET) para filtrar os resultados
// Se não existir 'sala', assume 0 (Todas). Se não existir 'search', assume vazio.
$id_sala = isset($_GET["sala"]) ? (int)$_GET["sala"] : 0; 
$pesquisa = isset($_GET["search"]) ? trim($_GET["search"]) : "";

// 3. CONSTRUÇÃO DA QUERY SQL: Cria uma consulta dinâmica baseada nos filtros aplicados
// Usamos LEFT JOIN para permitir pesquisar também pelo nome do software instalado
$query = "SELECT DISTINCT c.* FROM computadores c 
          LEFT JOIN computador_software cs ON c.id_computador = cs.id_computador
          LEFT JOIN software s ON cs.id_software = s.id_software
          WHERE 1=1"; // "1=1" é um truque para facilitar a adição de condições "AND" dinamicamente
$params = [];

// Se o utilizador selecionou uma sala específica, adiciona o filtro à query
if ($id_sala > 0) {
    $query .= " AND c.id_sala = ?";
    $params[] = $id_sala;
}

// Se o utilizador escreveu algo na pesquisa, procura no nome do PC ou no nome do Software
if (!empty($pesquisa)) {
    $query .= " AND (c.nome_computador LIKE ? OR s.nome_software LIKE ?)";
    $params[] = "%$pesquisa%";
    $params[] = "%$pesquisa%";
}

// Prepara e executa a consulta com os parâmetros de segurança para evitar SQL Injection
$stmt = $pdo->prepare($query); 
$stmt->execute($params); 
$computadores = $stmt->fetchAll(); 

// 4. CONTAGEM: Calcula o total de computadores encontrados após os filtros
$total_sala = count($computadores);
?> 
<!DOCTYPE html> 
<html lang="pt"> 
<head> 
    <meta charset="UTF-8"> 
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Gestão de Equipamentos</title> 
    <!-- Importação do Bootstrap para o design e Bootstrap Icons para os ícones -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.0/font/bootstrap-icons.css">
    <style> 
        /* Estilos personalizados para melhorar a estética do Bootstrap */
        body { background-color: #f4f7f6; font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif; }
        .navbar { box-shadow: 0 2px 4px rgba(0,0,0,.08); }
        .search-card { border: none; border-radius: 15px; box-shadow: 0 4px 12px rgba(0,0,0,.05); }
        .stats-badge { font-size: 0.9rem; padding: 8px 15px; border-radius: 50px; }
        .table-container { background: white; border-radius: 15px; overflow: hidden; box-shadow: 0 4px 12px rgba(0,0,0,.05); }
        .table thead { background-color: #f8f9fa; }
        .btn-primary { border-radius: 8px; padding: 8px 20px; }
        .form-control, .form-select { border-radius: 8px; border: 1px solid #dee2e6; padding: 10px 15px; }

        /* Estilos para os Indicadores de Saúde (Bolinhas coloridas) */
        .status-dot {
            height: 10px;
            width: 10px;
            border-radius: 50%;
            display: inline-block;
            margin-right: 8px;
        }
        .status-operacional { background-color: #28a745; box-shadow: 0 0 5px #28a745; }
        .status-manutencao { background-color: #ffc107; box-shadow: 0 0 5px #ffc107; }
        .status-avariado { background-color: #dc3545; box-shadow: 0 0 5px #dc3545; }
        .status-text { font-size: 0.8rem; font-weight: bold; text-transform: uppercase; color: #6c757d; }
    </style> 
</head> 
<body> 
    <!-- Barra de Navegação Superior -->
    <nav class="navbar navbar-dark bg-primary mb-4">
        <div class="container">
            <span class="navbar-brand mb-0 h1"><i class="bi bi-pc-display me-2"></i>Gestão de Inventário</span>
        </div>
    </nav>

    <div class="container"> 
        <!-- PAINEL DE PESQUISA E FILTROS -->
        <div class="card search-card p-4 mb-4">
            <form method="get" class="row g-3 align-items-end"> 
                <!-- Filtro por Sala -->
                <div class="col-md-4">
                    <label class="form-label fw-semibold text-secondary"><i class="bi bi-funnel me-1"></i> Filtrar por Sala</label> 
                    <select name="sala" class="form-select" onchange="this.form.submit()"> 
                        <option value="0">Todas as Salas</option>
                        <?php foreach($salas as $s): ?> 
                            <option value="<?= $s["id_sala"] ?>" <?= ($s["id_sala"]==$id_sala) ? "selected" : "" ?>> 
                                <?= htmlspecialchars($s["nome_sala"]) ?>
                            </option> 
                        <?php endforeach; ?> 
                    </select> 
                </div>
                <!-- Campo de Pesquisa de Texto -->
                <div class="col-md-5">
                    <label class="form-label fw-semibold text-secondary"><i class="bi bi-search me-1"></i> Pesquisar</label> 
                    <input type="text" name="search" class="form-control" placeholder="Nome do PC ou Software..." value="<?= htmlspecialchars($pesquisa) ?>">
                </div>
                <!-- Botões de Ação -->
                <div class="col-md-3 d-flex gap-2">
                    <button type="submit" class="btn btn-primary flex-grow-1">
                        <i class="bi bi-filter me-1"></i> Aplicar
                    </button> 
                    <a href="index.php" class="btn btn-outline-secondary" title="Limpar Filtros">
                        <i class="bi bi-arrow-clockwise"></i>
                    </a>
                </div>
            </form> 
        </div>

        <!-- CABEÇALHO DA LISTAGEM: Mostra o título dinâmico e a contagem total -->
        <div class="d-flex justify-content-between align-items-center mb-3 px-2">
            <h2 class="h5 mb-0 text-dark fw-bold">
                <?php if($id_sala > 0): ?>
                    Resultados para: <span class="text-primary"><?= htmlspecialchars($salas[array_search($id_sala, array_column($salas, 'id_sala'))]['nome_sala']) ?></span>
                <?php else: ?>
                    Todos os Equipamentos
                <?php endif; ?>
            </h2>
            <span class="badge bg-info text-dark stats-badge">
                <i class="bi bi-pc-display me-1"></i> Total: <strong><?= $total_sala ?></strong> computadores
            </span>
        </div>

        <!-- TABELA DE RESULTADOS -->
        <div class="table-container mb-5">
            <div class="table-responsive">
                <table class="table table-hover align-middle mb-0"> 
                    <thead>
                        <tr> 
                            <th class="ps-4">Equipamento</th> 
                            <th>Estado</th>
                            <th>Sistema Operativo</th> 
                            <th>Memória RAM</th> 
                            <th class="text-end pe-4">Ações</th> 
                        </tr> 
                    </thead>
                    <tbody>
                        <?php if (count($computadores) > 0): ?>
                            <?php foreach($computadores as $pc): ?> 
                            <tr> 
                                <!-- Nome e ID do Computador -->
                                <td class="ps-4">
                                    <div class="fw-bold text-dark"><?= htmlspecialchars($pc["nome_computador"]) ?></div>
                                    <small class="text-muted">ID: #<?= $pc["id_computador"] ?></small>
                                </td> 
                                <!-- Indicador de Saúde (Estado) -->
                                <td>
                                    <?php
                                    $estado = isset($pc["estado"]) ? $pc["estado"] : "Operacional";
                                    $classe_status = "";
                                    switch($estado) {
                                        case "Operacional": $classe_status = "status-operacional"; break;
                                        case "Manutenção":  $classe_status = "status-manutencao"; break;
                                        case "Avariado":    $classe_status = "status-avariado"; break;
                                        default:            $classe_status = "status-operacional";
                                    }
                                    ?>
                                    <div class="d-flex align-items-center">
                                        <span class="status-dot <?= $classe_status ?>"></span>
                                        <span class="status-text"><?= $estado ?></span>
                                    </div>
                                </td>
                                <!-- Sistema Operativo com Ícone -->
                                <td>
                                    <div class="d-flex align-items-center">
                                        <i class="bi bi-window text-secondary me-2"></i>
                                        <span><?= htmlspecialchars($pc["sistema_operativo"]) ?></span>
                                    </div>
                                </td> 
                                <!-- Memória RAM -->
                                <td>
                                    <span class="text-secondary"><i class="bi bi-memory me-1"></i><?= htmlspecialchars($pc["ram"]) ?></span>
                                </td> 
                                <!-- Botão para ver Detalhes -->
                                <td class="text-end pe-4">
                                    <a href="detalhe.php?id=<?= $pc["id_computador"] ?>" class="btn btn-sm btn-light border">
                                        <i class="bi bi-plus-circle me-1 text-primary"></i> Detalhes
                                    </a>
                                </td> 
                            </tr> 
                            <?php endforeach; ?> 
                        <?php else: ?>
                            <!-- Mensagem caso não existam resultados -->
                            <tr>
                                <td colspan="5" class="text-center py-5">
                                    <i class="bi bi-search fs-1 text-muted d-block mb-2"></i>
                                    <p class="text-muted mb-0">Nenhum computador encontrado com os critérios selecionados.</p>
                                    <a href="index.php" class="btn btn-link btn-sm">Limpar todos os filtros</a>
                                </td>
                            </tr>
                        <?php endif; ?>
                    </tbody>
                </table> 
            </div>
        </div>
    </div> 

    <!-- Scripts do Bootstrap para funcionalidades interativas -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body> 
</html>
